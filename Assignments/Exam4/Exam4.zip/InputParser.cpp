#include"InputParser.h"
#include<iostream>

Input readInput() {
	
	Input temp;
	std::cin >> temp.line;
	std::cin >> temp.letter;
	std::cin >> temp.repetitions;
	return temp;
}