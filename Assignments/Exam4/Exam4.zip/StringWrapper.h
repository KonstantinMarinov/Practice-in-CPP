#ifndef STRING_WRAPPER_H
#define STRING_WRAPPER_H
#include<string>
#include<iostream>
#include<algorithm>
#include<sstream>

class StringWrapper {
	std::string line;
	char letter{};
	int repetitions = 0;
public:

	StringWrapper(std::string line) : line(line) {
		
	};
	StringWrapper(char letter, int repetitions) : letter(letter), repetitions(repetitions) {
		
	};
	StringWrapper() {};

	StringWrapper getContent() const {
		StringWrapper r;
		r.letter = this->letter;
		r.line = this->line;
		r.repetitions = this->repetitions;
		return r;
	}
	StringWrapper append(StringWrapper r) {
		if (this->line == "") {
			this->line = r.line;
		}
		else {
			std::cout << this->line;
			for (int i = 0; i < r.repetitions; i++) {
				std::cout << r.letter;
			}
		}
		return *this;
		
	}
	void printContent() {
	}
	
	

};

#endif
